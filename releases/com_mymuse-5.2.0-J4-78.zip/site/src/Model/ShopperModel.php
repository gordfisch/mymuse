<?php
/**
 * @version		$Id:$
 * @package		mymuse
 * @copyright	Copyright © 2021 - Arboreta Internet Services - All rights reserved.
 * @license		GNU/GPL
 * @author		Gordon Fisch
 * @author mail	info@joomlamymuse.com
 * @website		http://www.joomlamymuse.com
 */

namespace Joomla\Component\Mymuse\Site\Model;

use Joomla\CMS\Factory;
use Joomla\CMS\Object\CMSObject;
use Joomla\CMS\MVC\Model\FormModel;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\User\User;
use Joomla\CMS\Router\Route;
use Joomla\Registry\Registry;
use Joomla\Component\Mymuse\Administrator\Helper\MymuseHelper;
use Joomla\Component\Mymuse\Site\Helper\CartHelper;
use Joomla\Component\Mymuse\Site\Service\Mymuse;

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.modelform');


class ShopperModel extends FormModel
{
	/**
	 * Shopper id
	 *
	 * @var int
	 */
	var $_id = null;
	
	/**
	 * var object The user
	 */
	var $_user = null;
	/**
	 * var object The shopper
	 */
	var $_shopper = null;
	
	/**
	 * var string error
	 */
	var $error = null;
	
	/**
	 * var object data
	 */
	var $data = null;

	/**
	 * var object order
	 */
	var $order= null;
	
	
	/**
	 * __construct
	 * 
	 * 
	 */
	function __construct( )
	{
		$this->user	= Factory::getApplication()->getIdentity();
	}
	
    
	/**
	 * getShopper
	 * 
	 * @return mixed object The shopper object or false
	 */
	public function getShopper()
	{

		// Lets load the data if it doesn't already exist

        if (empty( $this->_shopper ))
        {
        	$params = MyMuseHelper::getParams();
        	$user	= $this->user;
        	$jinput = Factory::getApplication()->input;
        	$task 	= $jinput->get('task');
        	$db 	= Factory::getDBO();
        	$session = Factory::getSession();
        	$guestcheckout = $session->get('guestcheckout');
        	$MyMuseCart		= Mymuse::getObject('Cart');
			$cart = $MyMuseCart->cart;

        	$shipping_needed = 0;
        	$app = Factory::getApplication();


        	for ($i=0;$i<$cart["idx"];$i++) {
        		if(isset($cart[$i]["product_physical"]) && $cart[$i]["product_physical"] && $params->get('my_use_shipping')){
        			$shipping_needed = 1;
        		}
        	}

        	//if this is no reg coming in for a download
        	if(($params->get('my_registration') == "no_reg" || $params->get('my_registration') == "full_guest") 
        			&& !$user->get('id') 
        			&& ($task == 'accdownloads' || $task == 'downloads') ){
        		$id = $jinput->get('id','');
        		if(!$id){
        			$this->setError(Text::_('COM_MYMUSE_NO_DOWNLOAD_KEY'));
        			return false;
        		}
        		$query = "SELECT notes from #__mymuse_order where order_number='$id'";
        		$db->setQuery($query);
        		$notes = $db->loadResult();
        		if(!$notes){
        			$this->setError(Text::_('COM_MYMUSE_NO_MATCHING_ORDER'));
        			return false;
        		}
      			
        		if(!$this->makeNoRegister()){
        			return false;
        		}
        		$registry = new JRegistry;
        		$registry->loadString($notes);
        		$fields = MyMuseHelper::getNoRegFields();

        		$jform = array();
        		foreach ($fields as $field){
        			if($registry->get($field)){

        				$jform['profile'][$field] = $registry->get($field);
        				
        			}
        		}
        		$jinput->post->set("jform", $jform);

        		$this->saveNoReg();
        		$this->loadProfile($this->_shopper);
        		return $this->_shopper;
        	}
        	
        	
        	// guest or regular user

        	if($task == 'guestcheckout' || $guestcheckout || $params->get('my_registration') == "no_reg"){
				$my_profile_key = 'mymusenoreg';
        	}else{
        		$my_profile_key = $params->get('my_profile_key','mymuse');
        	}

			if($user->get('id') > 0)
			{
				
				$this->_shopper = clone $user;
				$this->_id = $user->get('id');
				$this->_shopper->user_id = $user->get('id');
	
				$profile = (null !== $this->_shopper->get('profile'))? $this->_shopper->get('profile') : array();
		
				if(count($profile) < 1) {
					//try to load their profile
					
					if(!$this->loadProfile($this->_shopper)){
						$this->_shopper->perms = 0;
						return $this->_shopper;
					}else{
						$profile = $this->_shopper->profile;
					}
				}
		
				if(!isset($profile['shopper_group'])){
					$profile['shopper_group'] = 1;
				}
				$this->_shopper->perms = 1;
				
				//is there a profile to fill in?
				if(($params->get('my_registration') == "full" || $params->get('my_registration') == "full_guest")
						&& $my_profile_key != ''){
					
					//I want to see if any fields that are required have not been filled in
					$plugin = PluginHelper::getPlugin('user', $my_profile_key);

    				$profile_params = new Registry();
    				if(isset($plugin->params)){
    					$profile_params->loadString($plugin->params);

    					$fields = array_keys(json_decode($plugin->params, true));

    					foreach ($fields as $f) {
    						$field = preg_replace("/register-require_/",'',$f);
    						if (
    								$profile_params->get('register-require_' . $field, 1) == 2 &&
    								(!isset($profile[$field]) || $profile[$field] == "")
    						) {
    							//this guy needs to update profile
								$this->setError(Text::_('COM_MYMUSE_MISSING').$field);
    							$this->_shopper->perms = 0;
    							return $this->_shopper;
    						}
    					}
    				}


				}elseif($params->get('my_registration') == "jomsocial"){
					$this->_shopper->perms = 1;
					
					//I want to see if any fields that are required have not been filled in
					$query = "SELECT id,name FROM #__community_fields WHERE 
					required = 1 AND registration = 1 and type != 'group'";
					$db->setQuery($query);
					$fields = $db->loadObjectList();
					$user_id = $user->get('id');
					foreach($fields as $field){
						$query = "SELECT value FROM #__community_fields_values WHERE
						user_id=$user_id and field_id=".$field->id;
						$db->setQuery($query);
						$value = $db->loadResult();
						if(!$value || $value = ""){
							$this->_shopper->perms = 0;
						}
					}
				}elseif($params->get('my_registration') == "cb"){
					$this->_shopper->perms = 1;
					
					//I want to see if any fields that are required have not been filled in
					$query = "SELECT id,name FROM #__comprofiler_fields WHERE 
					required = 1 AND registration = 1 and table = 'comprofiler'";
					$db->setQuery($query);
					$fields = $db->loadObjectList();
					$user_id = $user->get('id');
					foreach($fields as $field){
						$query = "SELECT ".$field->name." as value FROM #__comprofiler WHERE
						user_id=$user_id";
						$db->setQuery($query);
						$value = $db->loadResult();
						if(!$value || $value = ""){
							$this->_shopper->perms = 0;
						}
					}
				}elseif($params->get('my_registration') == "no_reg"){ 
					
					$fields = MyMuseHelper::getNoRegFields();
					
					//I want to see if any fields that are required have not been filled in
					$plugin = PluginHelper::getPlugin('user', 'mymusenoreg');
					$profile_params = new Registry();
					$needed = 0;
					if(isset($plugin->params)){
						$profile_params->loadString($plugin->params);
						foreach ($fields as $field) {
							if(isset($profile[$field])){
								$value = $profile[$field];
								if (
									$profile_params->get('register-require_' . $field, 1) == 2 &&
									(!isset($value) || $value == "") &&
									!preg_match('/shipping/', $field)
								) {
									//this guy needs to update profile
									$needed++;
								}
								if (	
									$profile_params->get('register-require_' . $field, 1) == 2 &&
									$shipping_needed && preg_match('/shipping/', $field) &&
									(!isset($value) || $value == "")
								) {
									//this guy needs to update profile
									$needed++;
								}
							}
						}
					}

					
					if($needed){
						$this->_shopper->perms = 0;
					}
					reset($fields);
					foreach($fields as $field){
						if($user->get($field)){
							$this->_shopper->$field = $user->get($field);
							$_REQUEST[$field] = $user->get($field);
						}
					}

				
				}
				
				if(!isset($profile['shopper_group']) || $profile['shopper_group'] < 1){
						$profile['shopper_group'] = 1;
				}
				

				if(!$this->_shopper->shopper_group = $this->getShopperGroup($profile['shopper_group'])){
					$this->_shopper->shopper_group = $this->getShopperGroup(1);
				}

				$this->_shopper->discount = $this->_shopper->shopper_group->discount;
				$this->_shopper->shopper_group_name = $this->_shopper->shopper_group->shopper_group_name;

			}else{
				$this->_shopper = new CMSObject;
				$this->_shopper->id = 0;
				$this->_shopper->shopper_group = new CMSObject;
				$this->_shopper->shopper_group->discount = 0;
				$this->_shopper->shopper_group->id = $params->get("my_default_shopper_group_id");
				$this->_shopper->shopper_group_name = 'default';
				$this->_shopper->state = null;
				$this->_shopper->country = null;
				$this->_shopper->perms = null;
				$this->_shopper->user_id = null;
				
			}
		}

		return $this->_shopper;
	}
	/**
	 * getShopperByUser
	 * 
	 * @param object $user The user object
	 * @return mixed object The shopper object or false
	 */
	function getShopperByUser($userid = 0)
	{
		$params = MyMuseHelper::getParams();
		// Lets load the data if it doesn't already exist
        if ( $userid  )
        {
			$user = Factory::getApplication()->getIdentity($userid);
			$this->_shopper = $user;
			$this->_shopper->user_id = $userid;
			$this->_shopper->perms = 1;
			
			// Load the profile data from the database.
			$myparams = MyMuseHelper::getParams();
			$profile_key = $myparams->get('my_profile_key', 'mymuse');
			$db = Factory::getDbo();
			if($params->get('my_registration') == "full" && $profile_key != ''){
				$query = 'SELECT profile_key, profile_value FROM #__user_profiles' .
						' WHERE user_id = '.(int) $userid." AND profile_key LIKE '$profile_key.%'" .
						' ORDER BY ordering';
				$db->setQuery( $query);
					
				$results = $db->loadRowList();

				// Merge the profile data.
				$this->_shopper->profile = array();
					
				foreach ($results as $v)
				{
					$k = str_replace('mymuse.', '', $v[0]);
					$this->_shopper->profile[$k] = json_decode($v[1], true);
					if ($this->_shopper->profile[$k] === null)
					{
						$this->_shopper->profile[$k] = $v[1];
					}
				}
			}elseif($params->get('my_registration') == "jomsocial" && !isset($this->_shopper->profile)){
				//can we get their address? try the defaults

			}elseif($params->get('my_registration') == "cb" && !isset($this->_shopper->profile)){
				//can we get their address?
				
			}
		}

		return $this->_shopper;

	}
	
	/**
	 * This method should load profile data into the user object
	 *
	 * @param	array	$user		Holds the user data
	 * @param	array	$options	Array holding options (remember, autoregister, group)
	 *
	 * @return	boolean	True on success
	 */
	public function loadProfile(&$shopper, $options = array())
	{
	
		$jinput = Factory::getApplication()->input;
		$task 	= $jinput->get('task');
		$session = Factory::getSession();
		
		if($shopper->username == 'buyer'){
			$shopper->profile = $session->get('myprofile');
			//->get('com_users')->get('registration')->get('data')->get('profile');
			$shopper->profile['loaded'] = 1;
			return true;
		}
		

		// Load the profile data from the database.
		$app = Factory::getApplication();
		$myparams = MyMuseHelper::getParams();
		$profile_key = $myparams->get('my_profile_key', 'mymuse');
		$userId = $shopper->get('id');
		$db = Factory::getDbo();
		$query = 'SELECT profile_key, profile_value FROM #__user_profiles' .
				' WHERE user_id = '.(int) $userId." AND profile_key LIKE '$profile_key.%'" .
				' ORDER BY ordering';

		try 
		{
			$db->setQuery( $query);
			$results = $db->loadRowList();
		}
		catch (RuntimeException $e)
		{
		    $msg = $e->getMessage();
			$this->setRedirect( Route::_('index.php?option=com_mymuse'), $msg );
	        return false;
		}
		
	
		// Merge the profile data.
		$shopper->profile = array();
		if($results) {
			foreach ( $results as $v ) {
				$k = str_replace ( $profile_key . '.', '', $v [0] );
				$shopper->profile [$k] = json_decode ( $v [1], true );
				if ($shopper->profile [$k] === null) {
					$shopper->profile [$k] = $v [1];
				}
			}
		}


		if(!isset($shopper->profile['name'])){
			$shopper->profile['name'] = $shopper->name;
		}
		if(!isset($shopper->profile['email'])){
			$shopper->profile['email'] = $shopper->email;
		}
		if(isset($shopper->profile['region']) && !isset($shopper->profile['region_name']) && $profile_key != 'mymuse'){
			$shopper->profile['region_name'] = $shopper->profile['region'];
		}
		if(!isset($shopper->profile['shopper_group'])){
			$shopper->profile['shopper_group'] = 1;
		}

		$session->set('user', $shopper);
		$session->set('myprofile', $shopper->profile);
		
		return true;
	}
	
	
	/*
	 * Validate form
	 * Put post variables from form into session
	 * log them in
	*/
	function saveNoReg()
	{
		// Initialise variables.
		$app	= Factory::getApplication();
		$params = MyMuseHelper::getParams();
		$jinput = $app->input;
		$user	= $this->user;
		$fields = MyMuseHelper::getNoRegFields();
		$myparams = MyMuseHelper::getParams();
		$application = Factory::getApplication();
		// Get the user data.
		$post = $jinput->get('jform', array(), 'ARRAY');

		$post = Factory::getApplication()->input->post->getArray();
		$post = $post['jform'];

		// Save the data in the session.
		$app->setUserState('com_users.registration.data', $post);

		$MyMuseCart		=& Mymuse::getObject('cart','helper');
        $cart = $MyMuseCart->cart;
        $shipping_needed = 0;
        for ($i=0;$i<$cart["idx"];$i++) {
        	if(isset($cart[$i]["product_physical"]) && $cart[$i]["product_physical"] && $myparams->get('my_use_shipping')){
        		$shipping_needed = 1;
        	}
        }

		//I want to see if any fields that are required have not been filled in
		$plugin = PluginHelper::getPlugin('user', 'mymusenoreg');
		$profile_params = new Registry();
		$needed = 0;


		foreach ($fields as $field) {
			if(isset($post['profile'][$field])){
				$value = $post['profile'][$field];
				//echo "field = $field, value = $value <br>";
				if (
					$profile_params->get('register-require_' . $field, 1) == 2 &&
					(!isset($value) || $value == "")

				) {
					//check the shipping news
					if(strstr($field, 'shipping') && !$shipping_needed){
						continue;
					}

					//this guy needs to update profile
					$application->enqueueMessage('Please enter a value for '.$field, 'warning');
					$needed++;


				}
			}
		}

		if($needed){
			return false;
		}

		if($user->get('id')){
			//return true;
		}
		$db	= Factory::getDBO();
		$query = "SELECT * FROM #__users WHERE username='buyer'";
		$db->setQuery($query);
		$guest = $db->loadObject();

		if(!$guest){
			if(!$this->createGuestUser()){
				return false;
			}
			$db->setQuery($query);
			$guest = $db->loadObject();
		}
		if(!$guest){
			$this->setError(Text::_("MYMUSE_COULD_NOT_FIND_GUEST"));
			return false;
		}


		// Validate the posted data.
		$form	= $this->getForm();

		if (!$form) {
			$app->enqueueMessage("No form. ".$this->getError(), 'warning');	
			return false;
		}

		$data	= $this->validate($form, $post);

		// Check for validation errors.
		if ($data === false) {
			// Get the validation messages.
			$errors	= $this->getErrors();

			// Push up to three validation messages out to the user.
			for ($i = 0, $n = count($errors); $i < $n && $i < 3; $i++) {
				if ($errors[$i] instanceof Exception) {
					$app->enqueueMessage($errors[$i]->getMessage(), 'warning');
				} else {
					$app->enqueueMessage($errors[$i], 'warning');
				}
			}
			if(count($errors)){
				return false;
			}
		}


		//save the currrent cart
		$MyMuseCart = Mymuse::getObject('cart','helper');
		$currentCart = $MyMuseCart->cart;
		
		//perform the login action
		$credentials = array();
		$credentials['username'] = 'buyer';
		$credentials['password'] = $myparams->get('my_noreg_password');
		$options = array();
		$error = $app->login($credentials, $options);
		//print_pre($credentials); print_pre($myparams); exit;
		$queue = $app->getMessageQueue();
		if(count($queue)){
			//return false;
			print_pre($queue); exit;
		}
		
		//put the cart back in
		$session = Factory::getSession();
		$session->set("cart",$currentCart);
		$MyMuseCart->cart = $currentCart;
		
		$user	= Factory::getApplication()->getIdentity('buyer');
		
		//put values into session
		if(isset($post['profile']['region']) && !isset($post['profile']['region_name']) ){
			$db = Factory::getDBO();
		
			$query = "SELECT * FROM #__mymuse_state WHERE id='".$post['profile']['region']."'";
			$db->setQuery($query);
			if($row = $db->loadObject()){
				$post['profile']['region_name'] = $row->state_name;
			}
		}
		
		if(isset($post['profile']['shipping_region']) && !isset($post['profile']['shipping_region_name']) ){
			$db = Factory::getDBO();
		
			$query = "SELECT * FROM #__mymuse_state WHERE id='".$post['profile']['shipping_region']."'";
			$db->setQuery($query);
			if($row = $db->loadObject()){
				$post['profile']['shipping_region_name'] = $row->state_name;
			}
		}
		// set name
		if(isset($post['profile']['first_name'])){
			$post['profile']['name'] = $post['profile']['first_name']." ".@$post['profile']['last_name'];
		}

		if(isset($post)){

			$session->set('myprofile', $post['profile']);

		}
		$this->_shopper = $user;
		//$session->set('user', $user);
		
		return true;
	}
	
	
	function cancel()
	{
		$this->setRedirect( 'index.php' );
	}



	function getOrders()
	{
		$MyMuseCheckout =& Mymuse::getObject('checkout','helper');
		$user		= Factory::getApplication()->getIdentity();
		$user_id 	= $user->get('id');
		$db			= Factory::getDBO();
		$query = "SELECT * from #__mymuse_order WHERE user_id=$user_id ORDER BY created DESC";
		$db->setQuery($query);
		$orders = $db->loadObjectList();

		if($orders){
			foreach($orders as $key => $order){
				$orders[$key] = $MyMuseCheckout->getOrder($order->id);
				$orders[$key]->url = "index.php?option=com_mymuse&task=vieworder&orderid=".$order->id;
			}

			return $orders;
		}else{
			return NULL;
		}

		
		
	}
	

		
	function createGuestUser()
	{
		$myparams = MyMuseHelper::getParams();
 		$data = array('name' => 'Guest Buyer',
		'username' => 'buyer',
		'password1' => $myparams->get('my_noreg_password'),
		'password2' => $myparams->get('my_noreg_password'), 
		'email1' => 'guest@joomlamymuse.com',
		'email2' => 'guest@joomlamymuse.com' 
 		);
 		$config = Factory::getConfig();
 		$db		= Factory::getDbo();
 		$params = ComponentHelper::getParams('com_users');
 		
 		// Initialise the table with User.
 		$user = new User;
 		
 		// Prepare the data for the user object.
 		$data['email']		= $data['email1'];
 		$data['password']	= $data['password1'];
 		$useractivation = $params->get('useractivation');
 		
 		// Get the default new user group, Registered if not specified.
 		$system	= $params->get('new_usertype', 2);
 		$data['groups'][] = $system;

 		//print_pre($data); exit;
 		// Bind the data.
 		if (!$user->bind($data)) {
 			$this->setError(Text::sprintf('MYMUSE_REGISTRATION_BIND_FAILED', $user->getError()));
 			return false;
 		}
 		
 		// Load the users plugin group.
 		PluginHelper::importPlugin('user');
 		
 		// Store the data.
 		if (!$user->save()) {
 			$this->setError(Text::sprintf('MYMUSE_REGISTRATION_SAVE_FAILED', $user->getError()));
 			return false;
 		}

 		return $user->id;

		
	}
	
	/*
	 * makeNoRegister
	*
	* Get guest user and log them in, creating user if need be
	*
	* return boolen
	*/
	function makeNoRegister()
	{
		$app = Factory::getApplication();
		$jinput = $app->input;
		$user = Factory::getApplication()->getIdentity();
		$params	= ComponentHelper::getParams('com_users');
		$myparams = MymuseHelper::getParams();

		if($user->get('id')){
			return true;
		}
		$db	= Factory::getDBO();
		$query = "SELECT * FROM #__users WHERE username='buyer'";
		$db->setQuery($query);
		$guest = $db->loadObject();
		if(!$guest){
			if(!$this->createGuestUser()){
				return false;
			}
			$db->setQuery($query);
			$guest = $db->loadObject();
		}
		if(!$guest){
			$this->setError(Text::_("MYMUSE_COULD_NOT_FIND_GUEST"));
			return false;
		}

		$credentials = array();
		$credentials['username'] = 'buyer';
		$credentials['password'] = $myparams->get('my_noreg_password');
		$options = array(); 
		;

		//preform the login action
		return  $app->login($credentials, $options);

	}
	
	/**
	 * Method to get the registration form data.
	 *
	 * The base form data is loaded and then an event is fired
	 * for users plugins to extend the data.
	 *
	 * @return	mixed		Data object on success, false on failure.
	 * @since	1.6
	 */
	public function getData()
	{
		if ($this->data === null) {
	
			$this->data	= new CMSObject();
			$app	= Factory::getApplication();
			$params	= ComponentHelper::getParams('com_users');
	
			// Override the base user data with any data in the session.
			$temp = (array)$app->getUserState('com_users.registration.data', array());
			foreach ($temp as $k => $v) {
				$this->data->$k = $v;
			}
	
			// Get the groups the user should be added to after registration.
			$this->data->groups = array();
	
			// Get the default new user group, Registered if not specified.
			$new_usertype = $params->get('new_usertype', 2);
	
			$this->data->groups[] = $new_usertype;
	
			// Unset the passwords.
			unset($this->data->password1);
			unset($this->data->password2);

			$myparams = MymuseHelper::getParams();
			$my_registration = $myparams->get('my_registration', 'joomla'); //joomla, full or no_reg
			$results = array();

			if($my_registration == 'no_reg') {
				$results = $app->triggerEvent('onContentPrepareData', array('com_mymuse.noreg', $this->data));
			}elseif($my_registration == 'full'){
				$results = $app->triggerEvent('onContentPrepareData', array('com_user.profile', $this->data));
			}
			
	
			// Check for errors encountered while preparing the data.
			if (count($results) && in_array(false, $results, true)) {
				$this->setError($dispatcher->getError());
				$this->data = false;
			}
		}
	
		return $this->data;
	}
	
	/**
	 * Method to get the registration form.
	 *
	 * The base form is loaded from XML and then an event is fired
	 * for users plugins to extend the form with extra fields.
	 *
	 * @param	array	$data		An optional array of data for the form to interogate.
	 * @param	boolean	$loadData	True if the form is to load its own data (default case), false if not.
	 * @return	JForm	A JForm object on success, false on failure
	 * @since	1.6
	 */
	public function getForm($data = array(), $loadData = true)
	{
		// Get the form.
		$params = MyMuseHelper::getParams();

		if($params->get('my_registration') == "no_reg"){
			$form = $this->loadForm('com_mymuse.noreg', 'registration', array('control' => 'jform', 'load_data' => $loadData));
		}else{
			$form = $this->loadForm('com_mymuse.registration', 'registration', array('control' => 'jform', 'load_data' => $loadData));
		}

		
		if (empty($form)) {
			return false;
		}
	
		return $form;
	}
	
	/**
	 * Method to get the data that should be injected in the form.
	 *
	 * @return	mixed	The data for the form.
	 * @since	1.6
	 */
	protected function loadFormData()
	{
		return $this->getData();
	}
	
	/**
	 * Override preprocessForm to load the user plugin group instead of content.
	 *
	 * @param	object	A form object.
	 * @param	mixed	The data expected for the form.
	 * @throws	Exception if there is an error in the form event.
	 * @since	1.6
	 */
	protected function preprocessForm(Form $form, $data, $group = 'user')
	{
		$userParams	= ComponentHelper::getParams('com_users');
	
		//Add the choice for site language at registration time
		if ($userParams->get('site_language') == 1 && $userParams->get('frontend_userparams') == 1)
		{
			$form->loadFile('sitelang', false);
		}
	
		parent::preprocessForm($form, $data, $group);
	}
	
	/**
	 * Method to auto-populate the model state.
	 *
	 * Note. Calling getState in this method will result in recursion.
	 *
	 * @since	1.6
	 */
	protected function populateState()
	{
		// Get the application object.
		$app	= Factory::getApplication();
		$params	= $app->getParams('com_users');
	
		// Load the parameters.
		$this->setState('params', $params);
	}


	public function getShopperGroup ($id = 0) {
		if(!$id){
			return;
		}
		$db = Factory::getDBO();
		$query = 'SELECT a.*, u.title as shopper_group_name '
				. ' FROM #__mymuse_shopper_group as a'
				. ' LEFT JOIN #__usergroups as u ON u.id = a.usergroups_id '
				. ' WHERE a.id = '.$id
				;
		$db->setQuery($query);
		if($result = $db->loadObject()){
			return $result;
		}else{
			$result = $this->getShopperGroup(1);
			return $result;
		}
		return false;
	}
	
	

}
