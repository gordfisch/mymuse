<?php 
print_r($this->params);
if( ($this->params->get('info_block_show'))) : ?>
		<div class="product-details">

	<?php echo $this->loadTemplate('title'); ?>

<?php if( $this->params->get("info_block_show_title",0) ) : ?>
	<h2 class="product-details-title"><?php echo JText::_('COM_MYMUSE_PRODUCT_DETAILS'); ?></h2>
<?php endif; ?>


<ul class="productcontent-list">

	<?php 
echo $this->params->get("show_artist",0);
	if( $this->params->get("show_artist",0) ) : ?>
	<li class="product-content-item">
        <span class="category artist"><?php echo JText::_('COM_MYMUSE_ARTIST'); ?>:</span>
        <span class="value">
        	<?php if( $this->params->get("link_artist",0) ) :
        		 	$title = '<a href="'.$this->item->artist_link.'">'.$this->item->artist_link.'</a>';
                else:
                    $title = $this->item->artist_title;
                endif;
            ?>
        	<?php echo $title; ?>
        	</span>
    </li>
    <?php endif; ?>

	<li class="product-content-item">
        <span class="category cat-rls"><?php echo JText::_('COM_MYMUSE_PRODUCT_RELEASE_DATE'); ?>:</span>
        <span class="value"><?php echo $this->item->product_release_date; ?></span>
    </li>

    <li class="product-content-item">
        <span class="category cat-rls"><?php echo JText::_('COM_MYMUSE_PRODUCT_RELEASE_DATE'); ?>:</span>
        <span class="value"><?php echo $this->item->product_release_date; ?></span>
    </li>

"show_artist" 
"link_artist" 
"show_category" 
"link_category" 
"show_associations"
"show_author" 
"link_author" 
"show_release_date" 
"show_create_date" 
"show_modify_date" 
"show_publish_date" 
"show_hits" 
"show_vote"
"show_tags"
"show_product_sku" 
"show_special_status" 
"show_news_release_link" 
"show_media_link" 
"show_product_full_time"
"show_product_studio"
"show_product_publisher"
"show_product_producer"
"show_product_country"

		</div>
<?php endif; ?>