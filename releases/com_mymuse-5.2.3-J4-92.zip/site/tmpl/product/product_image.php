<?php 

use Joomla\CMS\Uri\Uri;

if( ($this->params->get('product_show_product_image') && $this->item->detail_image)) :?>
	<div class="product-image <?php echo $this->itemClass; ?>">
		<img src="<?php echo JUri::Root().$this->item->detail_image;?>"
			alt="<?php echo $this->item->title;?>"
			title="<?php echo $this->item->title;?>" 
			id="img_<?php echo $this->item->id; ?>"
			class="box-shadow"
			/>
	</div>
<?php endif; ?>