<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_mymuse
 *
 * @copyright   Copyright (C) 2005 - 2019 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Multilanguage;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;



HTMLHelper::_('behavior.multiselect');

$user      = Factory::getApplication()->getIdentity();
$userId    = $user->get('id');
$listOrder = $this->escape($this->state->get('list.ordering'));
$listDirn  = $this->escape($this->state->get('list.direction'));
$saveOrder = $listOrder == 'a.ordering';


?>
<h2><?php echo Text::_('COM_MYMUSE_TITLE_PRODUCTATTRIBUTES'); ?></h2>

<form action="<?php echo Route::_('index.php?option=com_mymuse&view=productattributeskus'); ?>" method="post" name="adminForm" id="adminForm">
	<div class="row">
		<div class="col-md-12">
			<div id="j-main-container" class="j-main-container">
				<?php
				// Search tools bar
				//echo LayoutHelper::render('joomla.searchtools.default', ['view' => $this]);
				?>
				<?php if (empty($this->items)) : ?>
					<div class="alert alert-info">
						<span class="fas fa-info-circle" aria-hidden="true"></span><span class="sr-only"><?php echo Text::_('INFO'); ?></span>
						<?php echo Text::_('JGLOBAL_NO_MATCHING_RESULTS'); ?>
					</div>
				<?php else : ?>

	<table class="table" id="articleList">
		<caption id="captionTable" class="sr-only">
			<?php echo Text::_('COM_MYMUSE_PRODUCTATTRIBUTESKUS'); ?>,
			<span id="orderedBy"><?php echo Text::_('JGLOBAL_SORTED_BY'); ?> </span>,
			<span id="filteredBy"><?php echo Text::_('JGLOBAL_FILTERED_BY'); ?></span>
		</caption>
		<thead>
			<tr>
				<th class="w-1">
					<input type="checkbox" name="checkall-toggle" value="" onclick="checkAll(this)" />
				</th>

				<th scope="col" class="w-1">
					<?php echo JHtml::_('grid.sort',  'COM_MYMUSE_NAME', 'a.name', $listDirn, $listOrder); ?>
				</th>
				<th scope="col" class="w-5">
					<?php echo JHtml::_('grid.sort',  'COM_MYMUSE_PRODUCT', 'p.title', $listDirn, $listOrder); ?>
				</th>
				<th scope="col" class="w-5 text-center d-none d-md-table-cell">
					<?php echo JHtml::_('grid.sort',  'Base Values', 'p.extra_base', $listDirn, $listOrder); ?>
				</th>
				<th scope="col" class="w-5 text-center d-none d-md-table-cell">
					<?php echo JHtml::_('grid.sort',  'CSS', 'p.extra_css', $listDirn, $listOrder); ?>
				</th>

				<th scope="col" class="w-1 d-none d-md-table-cell">
					<?php echo HTMLHelper::_('searchtools.sort', 'JGRID_HEADING_ID', 'a.id', $listDirn, $listOrder); ?>
				</th>
			</tr>
		</thead>

		<tbody <?php if ($saveOrder) :?> class="js-draggable" data-url="<?php echo $saveOrderingUrl; ?>" data-direction="<?php echo strtolower($listDirn); ?>" data-nested="true"<?php endif; ?>>
		<?php foreach ($this->items as $i => $item) :
			$ordering	= ($listOrder == 'a.ordering');
			$canCreate	= $user->authorise('core.create',		'com_mymuse');
			$canEdit	= $user->authorise('core.edit',			'com_mymuse');
			$canCheckin	= $user->authorise('core.manage',		'com_mymuse');
			$canChange	= $user->authorise('core.edit.state',	'com_mymuse');
			?>
			<tr class="row<?php echo $i % 2; ?>">
				<td class="text-center">
					<?php echo HTMLHelper::_('grid.id', $i, $item->id); ?>
				</td>

				<th scope="row">
					<div class="break-word">

							<a href="index.php?option=com_mymuse&task=productattributesku.edit&id=<?php echo $item->id; ?>"><?php echo $item->name; ?></a>
		
					</div>
				</th>

				<td class="small d-none d-md-table-cell">
					<?php echo $item->product_title; ?>
				</td>
				<td class="small d-none d-md-table-cell">
					<?php echo $item->extra_base; ?>
				</td>
				<td class="small d-none d-md-table-cell">
					<?php echo $item->extra_css; ?>
				</td>

				<td class="d-none d-md-table-cell">
					<?php echo $item->id; ?>
				</td>
			</tr>
			<?php endforeach; ?>
		</tbody>
	</table>

				<?php // Load the pagination. ?>
					<?php echo $this->pagination->getListFooter(); ?>

					
				<?php endif; ?>

				<input type="hidden" name="task" value="">
				<input type="hidden" name="boxchecked" value="0">
				<input type="hidden" name="filter_order" value="<?php echo $listOrder; ?>" />
				<input type="hidden" name="filter_order_Dir" value="<?php echo $listDirn; ?>" />
				<input type="hidden" name="parentid" value="<?php echo $this->parent->id; ?>" />
				<?php echo HTMLHelper::_('form.token'); ?>
			</div>
		</div>
	</div>
</form>
