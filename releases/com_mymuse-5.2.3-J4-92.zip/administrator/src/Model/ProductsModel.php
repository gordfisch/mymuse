<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_mymuse
 *
 * @copyright   Copyright (C) 2020 Arboreta Internet Services. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Joomla\Component\Mymuse\Administrator\Model;

\defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Associations;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Model\ListModel;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\Table\Table;
use Joomla\CMS\Workflow\Workflow;
use Joomla\Component\Content\Administrator\Extension\ContentComponent;
use Joomla\Database\ParameterType;
use Joomla\Utilities\ArrayHelper;
use Joomla\Component\Mymuse\Administrator\Helper\MymuseHelper;
use Joomla\Component\Mymuse\Administrator\Helper\MymuseStorage;

/**
 * Methods supporting a list of product records.
 *
 * @since  5.0.0
 */
class ProductsModel extends ListModel
{

	/**
	 * @var		object
     * @since  4.0
	 */
	protected $storage = null;


	/**
	 * Constructor.
	 *
	 * @param   array  $config  An optional associative array of configuration settings.
	 *
	 * @see     \JControllerLegacy
	 *
	 * @since   5.0.0
	 */
    public function __construct($config = array())
    {
    	if (empty($config['filter_fields'])) {
			$config['filter_fields'] = array(
				'id', 'a.id',
				'title', 'a.title',
				'alias', 'a.alias',
				'checked_out', 'a.checked_out',
				'checked_out_time', 'a.checked_out_time',
				'catid', 'a.catid', 'category_title',
				'artistid', 'a.artistid',
				'state', 'a.state',
				'access', 'a.access', 'access_level',
				'created', 'a.created',
				'created_by', 'a.created_by',
				'product_release_date', 'a.product_release_date',
				'modified', 'a.modified',
				'ordering', 'a.ordering',
				'featured', 'a.featured',
				'language', 'a.language',
				'hits', 'a.hits',
				'publish_up', 'a.publish_up',
				'publish_down', 'a.publish_down',
				'author', 'a.author'
			);
			if (Associations::isEnabled())
			{
				$config['filter_fields'][] = 'association';
			}

		}
		$this->storage 		= $GLOBALS['mymuseStorage'];

        parent::__construct($config);

    }

	/**
	 * Get the filter form
	 *
	 * @param   array    $data      data
	 * @param   boolean  $loadData  load current data
	 *
	 * @return  Form|null  The \JForm object or null if the form can't be found
	 *
	 * @since   3.2
	 */
	public function getFilterForm($data = array(), $loadData = true)
	{
		$form = parent::getFilterForm($data, $loadData);

		$params = ComponentHelper::getParams('com_mymuse');

		if (!$params->get('workflow_enabled'))
		{
			$form->removeField('stage', 'filter');
		}
		else
		{
			$ordering = $form->getField('fullordering', 'list');

			$ordering->addOption('JSTAGE_ASC', ['value' => 'ws.title ASC']);
			$ordering->addOption('JSTAGE_DESC', ['value' => 'ws.title DESC']);
		}
		$app = Factory::getApplication();
		$layout = $app->input->get('layout', '');

		if($layout == 'listtracks'){

			$form->removeField('fullordering', 'list');
			$form->setFieldAttribute('trackordering', 'name', 'fullordering');

		}else{
			
			$form->removeField('trackordering', 'list');
		}

		return $form;
	}

	/**
	 * Method to auto-populate the model state.
	 *
	 * Note. Calling getState in this method will result in recursion.
     *
     * @since 1.0
	 */
	protected function populateState($ordering = 'a.id', $direction = 'desc')
	{
		$app = Factory::getApplication();

		$forcedLanguage = $app->input->get('forcedLanguage', '', 'cmd');

		// Adjust the context to support modal layouts.
		if ($layout = $app->input->get('layout'))
		{
			$this->context .= '.' . $layout;
		}

		// Adjust the context to support forced languages.
		if ($forcedLanguage)
		{
			$this->context .= '.' . $forcedLanguage;
		}

		$search = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search');
		$this->setState('filter.search', $search);

		$featured = $this->getUserStateFromRequest($this->context . '.filter.featured', 'filter_featured', '');
		$this->setState('filter.featured', $featured);

		$published = $this->getUserStateFromRequest($this->context . '.filter.published', 'filter_published', '');
		$this->setState('filter.published', $published);

		$language = $this->getUserStateFromRequest($this->context . '.filter.language', 'filter_language', '');
		$this->setState('filter.language', $language);

		$downloadable = $this->getUserStateFromRequest($this->context . '.filter.downloadable', 'filter_downloadable');
		$this->setState('filter.downloadable', $downloadable);

		$physical = $this->getUserStateFromRequest($this->context . '.filter.physical', 'filter_physical');
		$this->setState('filter.physical', $physical);

        $parentid = $this->getUserStateFromRequest($this->context . '.filter.parentid', 'filter_parentid');
        $this->setState('filter.parentid', $parentid);

        $allfiles = $this->getUserStateFromRequest($this->context . '.filter.allfiles', 'filter_allfiles');
        $this->setState('filter.allfiles', $allfiles);

        $trackparentid = $this->getUserStateFromRequest($this->context . '.filter.trackparentid', 'filter_trackparentid');
        $this->setState('filter.trackparentid', $trackparentid);

		$formSubmited = $app->input->post->get('form_submited');

		$access     = $this->getUserStateFromRequest($this->context . '.filter.access', 'filter_access');
		$categoryId = $this->getUserStateFromRequest($this->context . '.filter.category_id', 'filter_category_id');
		$artistId 	= $this->getUserStateFromRequest($this->context . '.filter.artist_id', 'filter_artist_id');

		if ($formSubmited)
		{
			$access = $app->input->post->get('access');
			$this->setState('filter.access', $access);

			$categoryId = $app->input->post->get('category_id');
			$this->setState('filter.category_id', $categoryId);

			$artistId = $app->input->post->get('artist_id');
			$this->setState('filter.artist_id', $artistId);

		}

		// List state information.
		parent::populateState($ordering, $direction);

		// Force a language
		if (!empty($forcedLanguage))
		{
			$this->setState('filter.language', $forcedLanguage);
			$this->setState('filter.forcedLanguage', $forcedLanguage);
		}
	}



	/**
	 * Method to get a store id based on model configuration state.
	 *
	 * This is necessary because the model is used by the component and
	 * different modules that might need different sets of data or different
	 * ordering requirements.
	 *
	 * @param	string		$id	A prefix for the store id.
	 * @return	string		A store id.
	 * @since	1.6
	 */
	protected function getStoreId($id = '')
	{
		// Compile the store id.
		$id.= ':' . $this->getState('filter.search');
		$id.= ':' . $this->getState('filter.state');

		return parent::getStoreId($id);
	}

	/**
	 * Build an SQL query to load the list data.
	 *
	 * @return	JDatabaseQuery
	 * @since	1.6
	 */
	protected function getListQuery()
	{
		// Create a new query object.
		$db		= Factory::getContainer()->get('DatabaseDriver');
		$query	= $db->getQuery(true);

		// Select the required fields from the table.
		$query->select(
			$this->getState(
				'list.select',
				'a.*'
			)
		);
		$query->from('`#__mymuse_product` AS a');

		// Join over the users for the checked out user.
		$query->select('uc.name AS editor');
		$query->join('LEFT', '#__users AS uc ON uc.id=a.checked_out');

		
		// Filter by published state
		$published = $this->getState('filter.published');
		if (is_numeric($published)) {
			$query->where('a.state = '.(int) $published);
		} else if ($published === '') {
			$query->where('(a.state IN (0, 1))');
		}

		// Filter by featured.
		if ($featured = $this->getState('filter.featured')) {
			if($featured == "-1"){ $featured = 0;}
			$query->where("a.featured = '" . $featured."'");
		}

		// Filter by allfiles.
		$allfiles = $this->getState('filter.allfiles');
			if (is_numeric($allfiles)) {
				$query->where('a.product_allfiles = '.(int) $allfiles);
			} else if ($allfiles === '') {
				$query->where('(a.product_allfiles IN (0, 1))');
			}
		

		// Filter by parentid. Default is parentid = 0
		if ( $parentid = $this->getState('filter.parentid', 'default') ) {
			if($parentid == 'default'){ $parentid = 0; }
			$query->where("a.parentid = '" . $parentid."'");
		}

		// Filter by trackparentid. Default is trackparentid = 0
		if ( $trackparentid = $this->getState('filter.trackparentid', 'default') ) {
			if($trackparentid == 'default'){ $trackparentid = 0; }
			$query->where("a.track_parentid = '" . $trackparentid."'");
		}

		// Join over the categories.
		$query->select('c.title AS category_title');
		$query->join('LEFT', '#__categories AS c ON c.id = a.catid');
		
		// Join over the artist categories.
		$query->select('art.title AS artist_title');
		$query->join('LEFT', '#__categories AS art ON art.id = a.artistid');

		// Join over the associations.
		if (Associations::isEnabled())
		{
			$subQuery = $db->getQuery(true)
				->select('COUNT(' . $db->quoteName('asso1.id') . ') > 1')
				->from($db->quoteName('#__associations', 'asso1'))
				->join('INNER', $db->quoteName('#__associations', 'asso2'), $db->quoteName('asso1.key') . ' = ' . $db->quoteName('asso2.key'))
				->where(
					[
						$db->quoteName('asso1.id') . ' = ' . $db->quoteName('a.id'),
						$db->quoteName('asso1.context') . ' = ' . $db->quote('com_content.item'),
					]
				);

			$query->select('(' . $subQuery . ') AS ' . $db->quoteName('association'));
		}

		

		$query->select($db->quoteName('ag.title', 'access_level'));
		$query->join('LEFT', $db->quoteName('#__viewlevels', 'ag'), $db->quoteName('ag.id') . ' = ' . $db->quoteName('a.access'));

		//downloadable??
		if ($downloadable = $this->getState('filter.downloadable')) {
			$query->where('a.product_downloadable = 1');
		}

		//physical?
		if ($physical = $this->getState('filter.physical')) {
			$query->where('a.product_physical = 1');
		}
            

		// Filter by search in title
		$search = $this->getState('filter.search');
		if (!empty($search)) {
			if (stripos($search, 'id:') === 0) {
				$query->where('a.id = '.(int) substr($search, 3));
			} else {
				$search = $db->Quote('%'.$db->escape($search, true).'%');
                $query->where("a.title LIKE $search");
			}
		}

		// Filter by a single or group of categories.
		$baselevel = 1;
		$categoryId = $this->getState('filter.category_id');
		if (is_numeric($categoryId)) {
			$cat_tbl = Table::getInstance('Category', 'JTable');
			$cat_tbl->load($categoryId);
			$rgt = $cat_tbl->rgt;
			$lft = $cat_tbl->lft;
			$baselevel = (int) $cat_tbl->level;
			$query->where('c.lft >= '.(int) $lft);
			$query->where('c.rgt <= '.(int) $rgt);
		}
		elseif (is_array($categoryId)) {
			ArrayHelper::toInteger($categoryId);
			$categoryId = implode(',', $categoryId);
			$query->where('a.catid IN ('.$categoryId.')');
		}

		// Filter by a single or group of artists.
		$baselevel = 1;
		$artistId = $this->getState('filter.artist_id');
		if (is_numeric($artistId)) {
			$art_tbl = Table::getInstance('Category', 'JTable');
			$art_tbl->load($categoryId);
			$rgt = $art_tbl->rgt;
			$lft = $art_tbl->lft;
			$baselevel = (int) $art_tbl->level;
			$query->where('art.lft >= '.(int) $lft);
			$query->where('art.rgt <= '.(int) $rgt);
		}
		elseif (is_array($artistId)) {
			ArrayHelper::toInteger($artistId);
			$artistId = implode(',', $artistId);
			$query->where('a.artistid IN ('.$artistId.')');
		}

		// Add the list ordering clause.
		$orderCol	= $this->state->get('list.ordering');
		$orderDirn	= $this->state->get('list.direction');
        if ($orderCol && $orderDirn) {
		    $query->order($db->escape($orderCol.' '.$orderDirn));
		}

        //echo($query->__toString().'<br />'); 
		return $query;
	}

	/**
	 * Method to change the published state of one or more records.
	 *
	 * @param   array    &$pks   A list of the primary keys to change.
	 * @param   integer  $value  The value of the published state.
	 *
	 * @return  boolean  True on success.
	 *
	 * @since   4.0.0
	 */
	public function publish(&$pks, $value = 1) {

		$db = Factory::getContainer()->get('DatabaseDriver');
		$query = $db->getQuery(true);

		$query->update('`#__mymuse_product`');
		$query->set('state = ' . $value);
		$query->where('id IN (' . implode(',', $pks). ')');
		$db->setQuery($query);
		$db->execute();
	}

	/**
	 * Method to toggle the featured setting of products.
	 *
	 * @param	array	The ids of the items to toggle.
	 * @param	int		The value to toggle to.
	 *
	 * @return	boolean	True on success.
	 */
	public function featured($pks, $value = 0)
	{
		// Sanitize the ids.
		$pks = (array) $pks;
		ArrayHelper::toInteger($pks);

		if (empty($pks)) {
			$this->setError(Text::_('COM_MYMUSE_NO_ITEM_SELECTED'));
			return false;
		}

		try {
			$db = Factory::getContainer()->get('DatabaseDriver');

			$db->setQuery(
				'UPDATE #__mymuse_product AS a' .
				' SET featured = '.(int) $value.
				' WHERE id IN ('.implode(',', $pks).')'
			);
			if (!$db->execute()) {
				throw new Exception($db->getErrorMsg());
			} 

		} catch (Exception $e) {
			$this->setError($e->getMessage());
			return false;
		}

		$this->cleanCache();

		return true;
	}


	/**
	 * Method to delete of one or more records.
	 *
	 * @param   array    &$pks   A list of the primary keys to change.
	 *
	 * @return  boolean  True on success.
	 *
	 * @since   4.0.0
	 */
	public function delete(&$pks) {

		$db = Factory::getContainer()->get('DatabaseDriver');
		$query = $db->getQuery(true);

		$query->delete('`#__mymuse_product`');
		$query->where('id IN (' . implode(',', $pks). ')');
		$db->setQuery($query);
		$db->execute();

		//delete children
		$query = $db->getQuery(true);
		$query->delete('`#__mymuse_product`');
		$query->where('parentid IN (' . implode(',', $pks). ')');
		$db->setQuery($query);
		$db->execute();

	}

	/**
	 * Saves the manually set order of records.
	 *
	 * @param   array    $pks    An array of primary key ids.
	 * @param   integer  $order  +1 or -1
	 *
	 * @return  mixed
	 *
	 * @since   12.2
	 */
	public function saveorder($pks = null, $order = null)
	{
	
		MyMuseHelper::logMessage("here in model product\n");
		$table = $this->getTable('ProductTable');
		$conditions = array();
		MyMuseHelper::logMessage(get_class($table));

		if (empty($pks))
		{

			$this->setError("No ids");
			MyMuseHelper::logMessage("no ids\n");
            return false;
		}
	
		// Update ordering values
		foreach ($pks as $i => $pk)
		{

			$table->load((int) $pk);
	
			// Access checks.
			if (!$this->canEditState($table))
			{
				// Prune items that you can't change.
				unset($pks[$i]);
				JLog::add(Text::_('JLIB_APPLICATION_ERROR_EDITSTATE_NOT_PERMITTED'), JLog::WARNING, 'jerror');
				MyMuseHelper::logMessage("Not permitted\n");
			}
			elseif ($table->ordering != $order[$i])
			{
				$table->ordering = $order[$i];
	
	
				if (!$table->store())
				{
					$this->setError($table->getError());
					MyMuseHelper::logMessage($table->getError());
					return false;
				}
	
				// Remember to reorder within position and client_id
				$condition = $this->getReorderConditions($table);
				$found = false;
				MyMuseHelper::logMessage("$condition\n");
	
				foreach ($conditions as $cond)
				{
					if ($cond[1] == $condition)
					{
						$found = true;
						break;
					}
				}
	
				if (!$found)
				{
					$key = $table->getKeyName();
					$conditions[] = array($table->$key, $condition);
				}
			}
		}
	
	
		// Clear the component's cache
		$this->cleanCache();
	
		return true;
	}

	/**
	 * check_products
	 *
	 *
	 *  @return object
	 */
	
	function getCheck()
	{

		$params = MymuseHelper::getParams();
		$products = $this->getItems();
		$missing = array();

		foreach ($products as $product){
			$model = ListModel::getInstance('Products', 'MyMuse', array('ignore_request' => true));
			$model->setState('filter.downloadable', 1);
			$model->setState('filter.allfiles', 0);
			$model->setState('filter.parentid', $product->id);
			$product->items = $model->getItems();

			foreach($product->items as $item){
				
				$filenames = array();
				$previews = array();
				$path = MyMuseHelper::getDownloadPath($product->id,1);
				$preview_path = MyMuseHelper::getSitePath($product->id,1);
				
				if($item->file_preview != ''){
					$previews[] = $item->file_preview;
				}

				foreach($previews as $p){
					$full_path = $preview_path.$p;
					if($this->storage->fileExists($full_path)){
						$item->preview[$p]['class'] = "alert alert-success";
						$item->preview[$p]['result'] = Text::_('COM_MYMUSE_FOUND');
					}else{
						$item->preview[$p]['class'] = "alert alert-danger";
						$item->preview[$p]['result'] = Text::_('COM_MYMUSE_NOT_FOUND');
						$missing[] = $full_path;
					}

				}
				//get formats
				$fmodel = ListModel::getInstance('Products', 'MyMuse', array('ignore_request' => true));
				$fmodel->setState('filter.downloadable', 1);
				$fmodel->setState('filter.allfiles', 0);
				$fmodel->setState('filter.parentid', $product->id);
				$fmodel->setState('filter.trackparentid', $item->id);
				$product->formats = $fmodel->getItems();

				foreach($product->formats as $pformat){
					$jason = json_decode($pformat->digital);
					if(is_array($jason)){
						foreach($jason as $j){
							$filenames[] = $j->file_name;
						}
					}elseif(isset($jason->file_name)){
						$filenames[] = $jason->file_name;
					}
					


					if($params->get('my_download_dir_format')){
						foreach($params->get('my_formats') as $format){
							foreach($filenames as $f){
								$extension = pathinfo($f, PATHINFO_EXTENSION);
								if($extension == $format->format_value){
									$full_path = $path.$format->format_value.DS.$f;
									//echo $full_path."<br/>";
									if($this->storage->fileExists($full_path)){
										$item->download[$f]['class'] = "alert alert-success";
										$item->download[$f]['result'] = Text::_('MYMUSE_FOUND');
									}else{
										$item->download[$f]['class'] = "alert alert-danger";
										$item->download[$f]['result'] = Text::_('MYMUSE_NOT_FOUND');
										$missing[] = $full_path;
									}
								}
								
							}
						}
					}else{
						foreach($filenames as $f){
							$full_path = $path.$f;

							if($this->storage->fileExists($full_path)){
								$item->download[$f]['class'] = "alert alert-success";
								$item->download[$f]['result'] = Text::_('MYMUSE_FOUND');
							}else{
								$item->download[$f]['class'] = "alert alert-danger";
								$item->download[$f]['result'] = Text::_('MYMUSE_NOT_FOUND');
								$missing[] = $full_path;
							}
						}
					}
				}
				}

				
		}
		$products['missing'] = $missing;
		return $products;
	
	}

}