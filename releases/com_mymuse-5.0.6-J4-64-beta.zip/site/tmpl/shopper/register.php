<?php
/**
 * @version		$Id$
 * @package		mymuse
 * @copyright	Copyright © 2022 - Arboreta Internet Services - All rights reserved.
 * @license		GNU/GPL
 * @author		Gordon Fisch
 * @author mail	info@joomlamymuse.com
 * @website		http://www.joomlamymuse.com
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Associations;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\Component\Mymuse\Administrator\Helper\MymuseHelper;

$need_shipping = 0;
$need_closure = 0;
foreach ($this->form->getFieldsets() as $fieldset)
{
	if($fieldset->name == "shipping"){
		$need_shipping = 1;
		
	}
}

?>

<div class="mymuse_cart registration<?php echo $this->pageclass_sfx?>">
<?php if ($this->params->get('show_page_heading')) : ?>
	<h1><?php echo $this->escape($this->params->get('page_heading')); ?></h1>
<?php endif; ?>

	<form id="guest-registration" action="<?php echo Route::_('index.php?option=com_mymuse&view=cart&layout=cart'); ?>" method="post" class="form-validate">
	<input type="hidden" name="task" value="savenoreg">



<div class="blog-items columns-2">
	<div>

<?php foreach ($this->form->getFieldsets() as $fieldset): // Iterate through the form fieldsets and display each one.?>
	<?php $fields = $this->form->getFieldset($fieldset->name);?>
	
	<?php if (count($fields)):?>
	
	<?php if($fieldset->name == "address"): ?>
		<h4><?php echo Text::_('COM_MYMUSE_ADDRESS');?></h4>
	<?php endif; ?>
	
	<?php if($fieldset->name == "shipping"): ?>
		</div><div><h4><?php echo Text::_('COM_MYMUSE_SHIPPING');?></h4>
	<?php endif; ?>
	
	
		<fieldset>
		<?php if (isset($fieldset->label)):// If the fieldset has a label set, display it as the legend.
		?>
			<legend><?php echo Text::_($fieldset->label);?></legend>
		<?php endif;?>
			<dl>
		<?php foreach($fields as $field):// Iterate through the fields in the set and display them.?>
		
			<?php if ($field->hidden):// If the field is hidden, just display the input.?>
				<?php echo $field->input;?>
			<?php else:?>
				
			
				<dt>
					<?php echo $field->label; ?>
					<?php if (!$field->required && $field->type!='Spacer' && !preg_match("/shipping/",$field->name)): ?>
						<span class="optional"><?php echo Text::_('COM_MYMUSE_OPTIONAL'); ?></span>
					<?php endif; ?>
				</dt>
				<dd><?php echo ($field->type!='Spacer') ? $field->input : "&#160;"; ?></dd>
				<?php if($field->name == "jform[profile][shipping_add_address]"):
					$need_closure = 1; 
					?>
					<div id="shipping_fields" style="display: none">
				<?php endif?>
			<?php endif;?>
		<?php endforeach;?>
		<?php if($need_closure):?>
		</div>
	<?php endif?>
		
			</dl>
		</fieldset>
	<?php endif;?>
<?php endforeach;?>
</div>
	</div>

<div class="com-users-login__submit control-group">
                <div class="controls">
                    <button type="submit" class="btn btn-primary"><?php echo Text::_('JSAVE');?></button>
                </div>
                <div class="controls">
                	<a href="<?php echo Route::_('');?>" title="<?php echo Text::_('JCANCEL');?>" class="button"><?php echo Text::_('JCANCEL');?></a>
                </div>
            </div>
		<input type="hidden" name="option" value="com_mymuse" />
		<?php echo HTMLHelper::_('form.token');?>
	</form>
</div>

